package com.backendMarch.librarymanagementsystem.Enum;

public enum Department {

    CS,
    IT,
    MECH,
    EE,
    BIOTECH
}
