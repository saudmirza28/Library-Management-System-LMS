package com.backendMarch.librarymanagementsystem.Enum;

public enum TransactionStatus {
    SUCCESS,
    FAILED,
    PENDING
}
