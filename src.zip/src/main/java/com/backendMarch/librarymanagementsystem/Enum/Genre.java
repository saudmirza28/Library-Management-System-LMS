package com.backendMarch.librarymanagementsystem.Enum;

public enum Genre {
    SCIFI,
    ROMANTIC,
    FICTION,
    NON_FICTION,
    SPIRITUAL,
    BIOGRAPHY
}
