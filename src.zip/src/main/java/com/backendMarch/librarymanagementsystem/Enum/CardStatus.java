package com.backendMarch.librarymanagementsystem.Enum;

public enum CardStatus {
    ACTIVATED,
    DEACTIVATED,
    BLOCKED,
    EXPIRED
}
